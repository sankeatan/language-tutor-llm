import { Messages } from "@/components/pages/messages";

export default function Home() {
    return (
    <Messages />
  );
}
